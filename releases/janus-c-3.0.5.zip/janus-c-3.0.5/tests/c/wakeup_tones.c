#include <janus/janus.h>

int
main(void)
{
  //  janus_wakeup_tones(44100);
  return 1;
}
